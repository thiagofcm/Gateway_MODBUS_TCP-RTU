#include <stdio.h>

int main()
{
   printf("Oi Mundo!!! \n");
}