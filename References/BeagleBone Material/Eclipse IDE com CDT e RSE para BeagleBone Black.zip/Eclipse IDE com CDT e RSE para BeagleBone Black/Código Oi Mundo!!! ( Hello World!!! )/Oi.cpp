#include<iostream>
using namespace std;

int main()
{
   cout << "Oi Mundo!!!" << endl;
}

