#include <iostream>
#include "SimpleGPIO.h"
#include "SimpleGPIO.cpp"
#include <stdint.h>
#include <unistd.h>

using namespace std;

// Pinos Usados no Acionamento dos LEDs
// LED_Vermelho = P9_42 = GPIO7
//#define LED 7

// LED_Verde =    P9_14 = GPIO50
#define LED 50

// LED_Azul =     P9_16 = GPIO51
//#define LED 51

int main()
{


    gpio_export(LED);  // Exporta o GPIO60 para que possa ser acessado
    gpio_set_dir(LED, OUTPUT_PIN);  // Configura o GPIO60 como sa�da

    for(uint32_t u32_i=0; u32_i<20; u32_i++)
    {
        gpio_set_value(LED, LOW);  // Inicia com o LED desligado
        usleep(1000000);
        gpio_set_value(LED, HIGH);  // Liga o LED
        usleep(1000000);
    }

    gpio_set_value(LED, LOW);

    return 0;
}
